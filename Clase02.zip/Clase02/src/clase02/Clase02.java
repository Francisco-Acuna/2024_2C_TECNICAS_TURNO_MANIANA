/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase02;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here        
        
        System.out.println("Hello World!"); //esto es una sentencia
        //una sentencia es una orden que se le da al programa
        //para realizar una tarea espec�fica
        //las sentencias finalizan con ;
        //el ; separa una sentencia de otra
        
        //impresi�n con salto de l�nea
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        System.out.println("5");
        
        
        //impresi�n sin salto de l�nea
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.print("5");
        
        System.out.println("");
        
        // Variables
        
        /*
        Una variable es un nombre que se asocia con una porci�n de
        la memoria del ordenador, en donde se guarda el valor asignado
        a esa variable.
        Las variables deben declararse antes de usarlas.
        La declaraci�n es una sentencia en donde figura el tipo de dato
        y el nombre que le asignamos a la variable.
        */
        
        int a; //declaro una variable indicando el tipo de dato y su nombre
        a = 2; //asigno valor a la variable
        int b = 3; //declaraci�n y asignaci�n de valor en una sola l�nea
        a = 4; //cambio el valor de una variable
        
//        a = "hola"; error, no se puede asignar otro tipo de dato
//        char a; error, la variable ya fue creada con otro tipo de dato
//        int a; error, la variable ya existe

        //una variable puede tener una �nica declaraci�n
        //e innumerables valores. Valores siempre del mismo tipo de dato
        
        int c=12, d=32, e=42; //declaraci�n y asignaci�n m�ltiple en l�nea
        
        /*
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Tipos de datos primitivos
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        */
        
        //byte - ocupa 1 byte y representa un n�mero entero entre -128 y 127
        byte f = 100;
        System.out.println(f);
        
        //short 
        //ocupa 2 bytes y representa un n�mero entero entre -32.768 y 32.767
        //short g = 32768  error, excede la capacidad m�xima de representaci�n
        short g = -32768; //no se utilizan puntos para separar los miles
        System.out.println(g);
        
        //int
        //ocupa 4 bytes y representa un valor entero entre -2.147.483.648
        //y 2.147.483.647
        int h = 150356235;
        System.out.println(h);
        
        //long
        //ocupa 8 bytes y representa un n�mero muy grande 
        long i = 2233665599884452L;
        //debemos agregar un L al final del valor asignado
        //por convenci�n utilizamos L may�scula
        System.out.println(i);
        
        //float
        //ocupa 4 bytes y tiene una precisi�n de 32 bits
        float j = 14.25f; //los decimales se separan con punto
        //el float debe llevar una f al final de la literal
        System.out.println(j);
        
        //double
        //ocupa 8 bytes y tiene una precisi�n de 64 bits
        double k = 23.45; //no hace falta agregarle una letra al final
        System.out.println(k);
        
        //diferencia entre float y double
        float fl = 10f;
        double dl = 10;
        System.out.println(fl/3);
        System.out.println(dl/3);
        
    }
    
}

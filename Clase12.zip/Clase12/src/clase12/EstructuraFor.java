

package clase12;


public class EstructuraFor {
    public static void main(String[] args) {
        System.out.println("**Estructura for**");
        
        //imprimir los n�meros del 1 al 10 uno debajo del otro
        for(int i=1; i<=10; i++){
            System.out.println(i);
        }
        
        
    }
}

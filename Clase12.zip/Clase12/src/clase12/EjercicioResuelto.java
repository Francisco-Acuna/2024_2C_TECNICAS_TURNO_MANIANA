

package clase12;

import java.util.Random;
import java.util.Scanner;


public class EjercicioResuelto {
    public static void main(String[] args) {
    
        /*
        Crear una aplicaci�n que valide el ingreso a una
        plataforma Online Banking a trav�s de una clave Token.
        
        Se debe tener en cuenta lo siguiente:
        * La Clave Token debe ser un n�mero aleatorio
        de 6 d�gitos.
        * El cliente debe ingresar los campos Usuario,
        Contrase�a y Clave Token (todos obligatorios).
        * El campo Usuario no distingue min�sculas
        o may�sculas.
        * El campo Contrase�a es sensible a las
        min�sculas y may�sculas.
        La clave Token aleatoria se le informa al usuario al 
        pedirle que ingrese las credenciales.        
        * El cliente solo posee 3 intentos de logueo. 
	* Si alcanza los 3 intentos fallidos de forma
        consecutiva, la aplicaci�n deber� informar al
        usuario que debe dirigirse a la sucursal del
        banco m�s cercana para poder desbloquear
        sus credenciales.
        * Por cada intento fallido, la aplicaci�n debe
        preguntar al cliente si desea continuar
        colocando las credenciales de manera correcta.
        * Si el cliente coloca las credenciales de forma
        correcta, deber� informar que ha ingresado
        correctamente al Online Banking.
        */
        
        Random random = new Random();
        Scanner teclado = new Scanner(System.in);
        String usuario = "Pepito";
        String clave = "User1234";
        int token = random.nextInt(100000,1000000); // + 100000;
        //la clase Random la utilizamos para generar n�meros aleatorios
        //podemos pasar un solo par�metro de 100000 que generar� un n�mero
        //aleatorio entre 0 y 899999 al que le sumamos 100000 para que 
        //el n�mero resultante tenga finalmente 6 d�gitos.
        //O podemos pasar 2 par�metros indicando el inicio (incluido) y el 
        //final (excluido),
        String usuarioIngresado;
        String claveIngresada;
        int tokenIngresado;
        int intentosFallidos = 0;
        String respuesta;
        
        while(intentosFallidos<3){
            System.out.println("Bienvenido al On Line Banking");
            System.out.println("Su clave token es: " + token);
            System.out.println("Por favor, ingrese su usuario:");
            usuarioIngresado = teclado.nextLine();
            System.out.println("Ahora ingrese su clave:");
            claveIngresada = teclado.nextLine();
            System.out.println("Para finalizar, ingrese el nro token que le proporcionamos");
            tokenIngresado = teclado.nextInt();
            teclado.nextLine();
            
            if(usuarioIngresado.equalsIgnoreCase(usuario) &&
                    claveIngresada.equals(clave) &&
                    tokenIngresado == token){
                System.out.println("Usted ha ingresado correctamente!");
                break;
            }else{
                intentosFallidos++;
                System.out.println("Credenciales incorrectas.");
                System.out.println("Intentos fallidos: " + intentosFallidos);
                
                if(intentosFallidos<3){
                    do{
                        System.out.println("�Desea intentar nuevamente? (si/no):");
                        respuesta = teclado.nextLine().toLowerCase();
                        if(respuesta.equals("si")){
                            break;
                        }else if(respuesta.equals("no")){
                            System.out.println("Gracias por utilizar nuestro servicio!");
                            System.out.println("Vuelva prontos");
                            System.exit(0);
                        }else{
                            System.out.println("Por favor, responda con \"si\" o \"no\"");
                        }
                    }while(!respuesta.equals("no"));
                }
            }
        }
        
        if(intentosFallidos==3){
            System.out.println("Ha alcanzando el l�mite de intentos permitido.");
            System.out.println("Por favor dir�jase a la sucursal del banco m�s "
                    + "cercana para poder desbloquear sus credenciales.");
        }
        
        
    }
}

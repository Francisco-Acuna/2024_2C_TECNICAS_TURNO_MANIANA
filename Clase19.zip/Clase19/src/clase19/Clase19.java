package clase19;

import java.util.Arrays;
import javax.swing.JOptionPane;


public class Clase19 {


    public static void main(String[] args) {
        //si tuviera que guardar varios números en variables
        int numero1 = 10;
        int numero2 = 20;
        int numero3 = 50;
        int numero4 = 125;
        
        
        /*
        Podemos generar un conjunto de variables que tengan un mismo nombre
        que las agrupe a todas.
        Podemos acceder a cada variable por medio del índice.
        Recordemos que los índices comienzan en 0.
        De esta manera optimizamos la lectura de la información para 
        acceder por un mismo nombre a distintas variables y no por el nombre
        de cada una de ellas.
        */
        
        
        
        System.out.println("Arreglos o Arrays");
        
        /*
        declaración:
        tipoDeDato[] identificador; --> declaración
        tipoDeDato identificador[]; --> declaración
        identificador = new tipoDeDato[n]; --> definición de longitud
        la longitud es la cantidad de elementos que va a tener el arreglo
        */
        
        float[] temperaturas; //declaración
        temperaturas = new float[10]; // defino la longitud del arreglo
        
        float temperaturas2[]; //declaración
        temperaturas2 = new float[12];
        
        String[] nombres = new String[5]; //declaración y definición de longitud
        
        //asignación de valores a los elementos de un arreglo
        temperaturas[0] = 25.32f;
        temperaturas[1] = 12.56f;
//        temperaturas[2] = "Jose"; error, el elemento no es del mismo tipo de dato

        nombres[3] = "Juan";
//        nombres[5] = "Pablo"; error, no existe el índice 5
        
        //lectura de contenidos
        System.out.println(temperaturas[0]);
        System.out.println(nombres[3]);
        
        
        //inicialización
        int[] numeros = {12, 59, 87, 129, 0};
        //declaración de arreglo, de longitud e inicialización de elementos
        //la cantidad de elementos que declare, definen su longitud para siempre
        
        //mostrar el contenido de un arreglo
        System.out.println(numeros); //no muestra el contenido
        //muestra la posición de memoria del vector.
        //porque el nombre es una referencia, no es el contenido.
        System.out.println("Contenido de un arreglo:");
        System.out.println(numeros[0]);
        System.out.println(numeros[1]);
        System.out.println(numeros[2]);
        System.out.println(numeros[3]);
        System.out.println(numeros[4]);
        
        System.out.println("\nCon un contador o referencia:");
        int contador = 0;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        
        System.out.println("\nCon un for:");
        for(int i=0; i<5; i++){
            System.out.println(numeros[i]);
        }
        
        System.out.println("\n");
        for(int i=0; i<5; i++){
            System.out.println("El contenido del vector en la posición "+i+" es "+numeros[i]);
        }
        
        //longitud de un vector
        System.out.print("\nLongitud del vector: ");
        System.out.println(numeros.length);
        
        System.out.println("\nRecorrido utilizando length");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println(numeros[i]);
        }
        
        //copias de arreglos
        char[] origen = {'a', 'b', 'c', 'x', '@'};
        
        //creamos un arreglo de destino con la misma longitud que origen
        char[] destino = new char[origen.length];
        
        //recorremos los arreglos
        System.out.println("Arreglo de origen:");
        for(int i=0; i<origen.length; i++) System.out.println(origen[i]);
        System.out.println("\nArreglo de destino:");
        for(int i=0; i<destino.length; i++) System.out.println(destino[i]);
        
        System.out.println("");
        
        //para copiar contenido
//        System.out.println("Asignando valor por posición de a uno");
//        destino[0] = origen[0];
//        destino[1] = origen[1];
//        destino[2] = origen[2];
//        destino[3] = origen[3];
//        destino[4] = origen[4];
//        
//        //recorremos los arreglos
//        System.out.println("Recorrida luego de la copia uno a uno");
//        System.out.println("Arreglo de origen:");
//        for(int i=0; i<origen.length; i++) System.out.println(origen[i]);
//        System.out.println("\nArreglo de destino:");
//        for(int i=0; i<destino.length; i++) System.out.println(destino[i]);
        
        System.out.println("Copia  con for");
        for(int i=0; i<origen.length; i++){
            destino[i] = origen[i];
        }
        
        //recorremos los arreglos
        System.out.println("Arreglo de origen:");
        for(int i=0; i<origen.length; i++) System.out.println(origen[i]);
        System.out.println("\nArreglo de destino:");
        for(int i=0; i<destino.length; i++) System.out.println(destino[i]);
        
        System.out.println("\n***************************\n");
        //copia de vectores utilizando System.arraycopy
        int[] pares = {2, 4, 6, 8, 10};
        int pares2[] = new int[pares.length];
        
        System.out.println("Recorrido antes de copiar:");
        for(int i=0; i<pares.length; i++){
            System.out.println(pares[i]);
        }
        
        for(int i=0; i<pares2.length; i++){
            System.out.println(pares2[i]);
        }
        
        System.arraycopy(pares, 0, pares2, 0, pares.length);
        //arraycopy() es un método de la clase System que sirve para realizar
        //copias de arreglos.
        //el primer parámetro pide el arreglo de origen
        //el segundo parámetro pide la posición desde la que se empezará a copiar
        //el tercer parámetro pide el arreglo de destino
        //el cuarto parámetro pide la posición hacia la que empezará a copiar
        //el quinto parámetro pide la cantida de elementos que va a copiar
        
        System.out.println("\nRecorrido luego de copiar con arraycopy\n");
        System.out.println("pares");
        for(int i=0; i<pares.length; i++){
            System.out.println(pares[i]);
        }
        System.out.println("pares2");
        for(int i=0; i<pares2.length; i++){
            System.out.println(pares2[i]);
        }
        System.out.println("\n**************************\n");
        //ordenar un vector
        int[] vector = {4, 56, 73, 12, 38, 1, 60, 7};
        System.out.println("Contenido del vector");
        for (int i = 0; i < vector.length; i++) {
            System.out.println(vector[i]);
        }
        
        Arrays.sort(vector);
        //ordenó el vector
        System.out.println("vector ordenado:");
        for (int i = 0; i < vector.length; i++) {
            System.out.println(vector[i]);
        }
        System.out.println("");
        //recorrido foreach JDK 5
        //simplificación del for
        /*
        for(tipo_de_dato elemento : colección){
            //sentencias que se ejecutan en cada iteración
        }
        */
        
        //ya no necesitamos preocuparnos por el índice, ni por el límite, 
        //ni por el incremento
        
        System.out.println("Recorrido foreach");
        for(int v:vector) System.out.println(v);
        
        //promedio
        System.out.println("##################");
        System.out.println("Cálculo de promedio");
        int[] datos = {12, 35, 59, 68, 12};
        float suma = 0;
        
//        for(int i=0; i<datos.length; i++){
//            System.out.println(datos[i]);
//        }
        
        for(int d:datos) System.out.println(d);
        
        System.out.println("Realizamos la suma:");
        for(int d:datos) suma+=d;
        System.out.println(suma);
        float promedio = suma / datos.length;
        System.out.println(promedio);
        
        //cálculo del mayor
        int mayor = datos[0];
        for(int d:datos) if(d>mayor) mayor=d;
        System.out.println("El mayor número encontrado fue " + mayor);
        
        //cálculo del menor
        int menor = datos[0];
        for(int d:datos) if(d<menor) menor=d;
        System.out.println("El menor número encontrado fue " + menor);

        /*
        Crear un vector de 10 posiciones
        Pedirle al usuario que cargue 10 valores para ese vector
        Indicar cuántos números pares y cuántos impares hay
        Indicar cuántas veces se repitió el número 2
        */
       
        
    }
    
}

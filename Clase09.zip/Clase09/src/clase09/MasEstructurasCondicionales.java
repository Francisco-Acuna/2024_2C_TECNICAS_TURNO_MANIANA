

package clase09;


public class MasEstructurasCondicionales {
    public static void main(String[] args) {
        
        int edad = 1;
        String mensaje;
        
        if(edad>=18){
            mensaje = "Es mayor de edad";
        }else{
            mensaje = "No es mayor de edad";
        }
        
        System.out.println(mensaje);
        
        //operador ternario
         mensaje = (edad>=18) ? "Es mayor de edad" : "No es mayor de edad";
        System.out.println(mensaje);
        
        //si quisi�ramos indicar un color de acuerdo al siguiente esquema:
        //1=rojo, 2=azul, 3=celeste, 4=violeta, cualquier otro n�mero=negro
        
        int nro = 30;
        
        if(nro == 1){
            System.out.println("rojo");
        }else if(nro == 2){
            System.out.println("azul");
        }else if(nro == 3){
            System.out.println("celeste");
        }else if(nro == 4){
            System.out.println("violeta");
        }else{
            System.out.println("negro");
        }
        
        System.out.println("** Estructura switch**");
        switch(nro){
            case 1: System.out.println("rojo"); break;
            case 2: System.out.println("azul"); break;
            case 3: System.out.println("celeste"); break;
            case 4: System.out.println("violeta"); break;
            default: System.out.println("negro");
        }
        
        //el default no es obligatorio
        
        int dia = 60;
        
        switch(dia){
            case 1: System.out.println("El d�a es lunes"); break;
            case 2: System.out.println("El d�a es martes"); break;
            case 3: System.out.println("El d�a es mi�rcoles"); break;
            case 4: System.out.println("El d�a es jueves"); break;
            case 5: System.out.println("El d�a es viernes"); break;
            case 6: System.out.println("El d�a es s�bado"); break;
            case 7: System.out.println("El d�a es domingo"); break;
            default:System.out.println("No es un d�a v�lido");
        }
        
        //los casos en los que no haya un break, se pueden tomar como un or
        
        String opcion = "s";
        
        switch(opcion){
            case "s":
            case "S":
                System.out.println("Sale del sistema"); break;
            case "c":
            case "C":
                System.out.println("Contin�a"); break;
            default: System.out.println("Opci�n no v�lida");
        }
        
        switch(dia){
            case 1, 2, 3, 4, 5:
                System.out.println("Es d�a de semana"); break;
            case 6, 7:
                System.out.println("Es fin de semana!!"); break;
            default: System.out.println("No es un n�mero v�lido");
        }
        
        //la estructura switch no admite expresiones del tipo float, 
        //ni double ni long
        
        //expresiones switch a partir del JDK 12
        //se reemplazan los : por las ->
        //se elimina la sentencia break
        
        dia = 3;
        mensaje = switch(dia){
            case 1 -> "El d�a es lunes";
            case 2 -> "El d�a es martes";
            case 3 -> "El d�a es mi�rcoles";
            case 4 -> "El d�a es jueves";
            case 5 -> "El d�a es viernes";
            case 6 -> "El d�a es s�bado";
            case 7 -> "El d�a es domingo";
            default -> "El d�a no existe";
        };
        
        //en las expresiones switch el obligatorio el uso del default
        
        System.out.println(mensaje);
    }
}

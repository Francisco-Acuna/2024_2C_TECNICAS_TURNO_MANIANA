/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase09;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
	Ejercicio1:
        Seg�n la edad de una persona mostraremos los siguientes mensajes:
        menos de 12 a�os: "eres un ni�o"
        entre 12 de 17 a�os: "eres un adolescente"
        entre 18 y 39 a�os: "eres joven" 
        entre 40 y 70: "eres maduro"
        71 para arriba: "eres anciano"
        */
        
        Scanner teclado = new Scanner(System.in);
        
//        System.out.println("Ingrese su edad: ");
//        int edad = teclado.nextInt();
//
//        if(edad < 12){
//            System.out.println("Eres un ni�o.");
//        }else if(edad <= 17){
//            System.out.println("Eres un adolescente.");
//        }else if(edad <= 39){
//            System.out.println("Eres joven.");
//        }else if(edad <= 70){
//            System.out.println("Eres maduro.");
//        }else{
//            System.out.println("Eres anciano.");
//        }
//        
//        if(edad <= 70){
//            if(edad>=40){
//                System.out.println("Eres maduro");
//            }else if(edad>=18){
//                System.out.println("Eres joven");
//            }else if(edad>=12){
//                System.out.println("Eres un adolescente");
//            }else{
//                System.out.println("Eres un ni�o.");
//            }
//        }else{
//            System.out.println("Eres un anciano.");
//        }
        
        /*
        Ejercicio 2:
        Dada la siguiente tabla del tiempo, hacer un
        programa que indique qu� puede hacer una
        persona con dicho pron�stico:
        
        Temperatura     Tiempo      Sugerencia
        > 25�           Soleado     Caminar y tomar sol
        > 15� y <=25�   Soleado     Caminar
        <=15�           Soleado     Caminar con campera
        <10�            Lluvia      Quedarse en casa o salir con paraguas y campera
        <10�            Nieve       Esquiar
        
        Luego pedirle al usuario que ingrese una temperatura y una condici�n
        del tiempo v�lida (Soleado, lluvia o nieve) e indicarle la sugerencia.
        */
        
//        int temperatura;
//        String tiempo;
//        
//        System.out.println("Ingrese la temperatura en grados cent�grados y solo n�meros:");
//        temperatura = teclado.nextInt();
//        System.out.println("Ingrese una condici�n del tiempo:");
//        System.out.println("(soleado, lluvia o nieve)");
//        teclado.nextLine();
//        tiempo = teclado.nextLine();
//        String mensajeSinSugerencia = "No tenemos una sugerencia para las opciones ingresadas.";
//        if(tiempo.equalsIgnoreCase("soleado")){
//            if(temperatura > 25){
//                System.out.println("Sugerencia: Caminar y tomar sol.");
//            }else if(temperatura>15 && temperatura<=25){
//                System.out.println("Sugerencia: Caminar.");
//            }else if(temperatura<=15){
//                System.out.println("Sugerencia: Caminar con campera.");
//            }
//        }else if(tiempo.equalsIgnoreCase("lluvia")){
//            if(temperatura<10){
//                System.out.println("Sugerencia: Quedarse en casa o salir con paraguas y campera");
//            }else{
//                System.out.println(mensajeSinSugerencia);
//            }
//        }else if(tiempo.equalsIgnoreCase("nieve")){
//            if(temperatura<10){
//                System.out.println("Sugerencia: esquiar.");
//            }else{
//                System.out.println(mensajeSinSugerencia);
//            }
//        }else{
//            System.out.println(mensajeSinSugerencia);
//        }
        
        
        /*
        Ejercicio 3:
        Solicitar al usuario que ingrese 3 n�meros. 2 positivos y 1 negativo
        (en cualquier orden).
        Luego, informar por pantalla la multiplicaci�n de los n�meros que son 
        positivos
         */
        
        int num1;
        int num2;
        int num3;
        
        System.out.println("Por favor, ingrese 3 n�meros enteros. 2 positivos "
                + "y 1 negativo.En cualquier orden.");
        System.out.println("A continuaci�n ingrese el primer n�mero");
        num1 = teclado.nextInt();
        System.out.println("Ingrese el segundo n�mero:");
        num2 = teclado.nextInt();
        System.out.println("Ingrese el tercer n�mero:");
        num3 = teclado.nextInt();
        
        
        if(num1>0 && num2>0 && num3>0){
            System.out.println("Usted ingres� los tres n�meros positivos.");
        }else{
            if(num1 > 0){
                if(num2 > 0){
                    System.out.println(num1 * num2);
                }else if(num3>0){
                    System.out.println(num1 * num3);
                }else{
                    System.out.println("Hay m�s de un n�mero negativo");
                }
            }else if(num3>0){
                if(num2>0){
                    System.out.println(num2*num3);
                }else{
                    System.out.println("Hay m�s de un n�mero negativo");
                }
            }else{
                System.out.println("Hay m�s de un n�mero negativo");
            }
        }
    }
    
}

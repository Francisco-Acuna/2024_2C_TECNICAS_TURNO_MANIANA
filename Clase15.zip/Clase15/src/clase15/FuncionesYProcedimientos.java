

package clase15;

import java.util.Scanner;


public class FuncionesYProcedimientos {
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("** Funciones y procedimientos **");
        
        /*
        Las funciones y procedimientos son un bloque de c�digo que 
        contienen una o m�s instrucciones, al cual podemos invocar
        para que sean ejecutadas. Las funciones y los procedimientos
        nos van a ayudar a hacer nuestro c�digo m�s legible y evitar
        c�digo duplicado.
        */
        
        //Funciones
        /*
        Las funciones siempre retornan un valor.
        En su declaraci�n deben indicar qu� tipo de valor retornan.
        En su cuerpo deben contener la sentencia return con el retorno
        del tipo de dato que se indic� en su cabecera.
        */
        
        System.out.println("Funciones");
        int numero = retornarNumeroDiez();
        System.out.println(numero);
        
        int primerNumero = 10;
        int segundoNumero = 200;
        int suma = sumarDosNumerosEnteros(primerNumero, segundoNumero);
        System.out.println(suma);
        System.out.println(sumarDosNumerosEnteros(15, 20));
        
        suma = sumarDosNumerosEnteros(retornarNumeroDiez(), segundoNumero);
        System.out.println(suma);
        
        System.out.println(esPar(1));
        
        System.out.println("Ingrese un n�mero entero para saber si es par");
        int numerito = teclado.nextInt();
        if(esPar(numerito)) System.out.println("El n�mero es par");
        else System.out.println("El n�mero no es par");
        
        System.out.println("\n**Procedimientos**");
        
        /*
        Los procedimientos no tienen un retorno de valor.
        En su declaraci�n deben llevar la palabra reservada 'void'
        para indicar que no tienen retorno.
        */
        
        saludar();
        
        for (int i = 0; i < 5; i++) {
            saludar();
        }
        
        teclado.nextLine();
        System.out.println("Ingrese su nombre:");
        String nombreUsuario = teclado.nextLine();
        saludarNombre(nombreUsuario);
        
        System.out.println("Ingrese la base del rect�ngulo");
        float base = teclado.nextFloat();
        System.out.println("Ingrese la altura del rect�ngulo");
        float altura = teclado.nextFloat();
        calcularAreaRectangulo(base, altura);
        System.out.println(calcularAreaRectangulo2(base, altura));
        
        int nro1 = 10;
        int nro2 = 20;
        String nombre = "Juan";
        sumarParImpar(nro1, nro2, nombre);
        
    }//fin del m�todo main
    
    //ejemplos de funciones
    public static int retornarNumeroDiez(){
        return 10;
    }
    
    public static int sumarDosNumerosEnteros(int nro1, int nro2){
        int suma = nro1 + nro2;
        return suma;
    }
    
    public static boolean esPar(int nro){
//        if(nro % 2 == 0){
//            return true;
//        }else{
//            return false;
//        }
        //lo anterior no se hace
        return nro%2 == 0;
    }
    
    //ejemplos de procedimientos
    public static void saludar(){
        System.out.println("Hola Mundo!");
    }
    
    public static void saludarNombre(String nombre){
        System.out.println("Hola " + nombre + "!!");
    }
    
    public static void calcularAreaRectangulo(float base, float altura){
        float resultado = base * altura;
        System.out.println("El �rea del rect�ngulo es de " + resultado);
    }
    
    //ejemplo del anterior pero como funci�n
    public static float calcularAreaRectangulo2(float base, float altura){
        float resultado = base * altura;
        return resultado;
    }
    
    //reutilizando funciones y procedimientos
    /**
     * Este procedimiento pide dos n�meros enteros y un String.
     * Primero saluda al nombre ingresado como String.
     * Y luego realiza la suma de los dos n�meros ingresados.
     * Informa por consola, si la suma dio par o impar.
     * @param numero1
     * @param numero2
     * @param nombre 
     */
    public static void sumarParImpar(int numero1, int numero2, String nombre){
        saludarNombre(nombre);
        if(esPar(sumarDosNumerosEnteros(numero1, numero2))){
            System.out.println("La suma es par");
        }else{
            System.out.println("La suma es impar");
        }
    }
    
    
} //fin de la clase



package curso.java.condicionales;

import java.util.Scanner;


public class Clase08 {
    public static void main(String[] args) {
        //condicionales
        
        System.out.println("** Estructura if **");
        
        int nro1 = 5;
        int nro2 = 10;
        
        if(nro1 > nro2){
            System.out.println("El nro1 es mayor al nro2");
        }
        
        System.out.println("Fin de la estructura if");
        
        if(nro1 == 5){
            System.out.println("El nro1 es igual a 5");
        }
        
        boolean log1 = false;
        
        if(log1){ //no se compara con == true cuando es booleano
            System.out.println("La variable log1 es verdadera");
        }
        
        if(nro1==5 && nro2!=5 && !log1){
            System.out.println("El nro1 es 5, el nro2 es distinto a 5 y log1 es verdadera");
        }
        
        if(nro1 != nro2) System.out.println("Ambos n�meros son distintos");
        //if en l�nea, si solo se va a ejecutar una �nica sentencia en el cuerpo del if
        
        System.out.println("\n**Estructura if-else**");
        
        if(nro1 > nro2){
            System.out.println("El nro1 es mayor al nro2.");
        }else{
            System.out.println("El nro1 no es mayor al nro2");
        }
        
        //tambi�n se puede escribir en l�nea siempre que se ejecute una sola
        //sentencia por bloque
        if(nro1>nro2) System.out.println("El nro1 es mayor al nro2");
        else System.out.println("EL nro1 no es mayor al nro2");
        
        System.out.println("\n**Estructura if-else if-else**");
        if(nro1 > nro2){
            System.out.println("El nro1 es mayor al nro2");
        }else if(nro2 > nro1){
            System.out.println("El nro2 es mayor al nro1");
        }else{
            System.out.println("Ambos n�meros son iguales!");
        }
        
        Scanner teclado = new Scanner(System.in);
        int edad;
        String genero;
        System.out.println("Ingrese su edad:");
        edad = teclado.nextInt();
        teclado.nextLine();
        System.out.println("Ingrese su g�nero:");
        genero = teclado.nextLine();
        
//        if(edad >= 60 && genero.equals("mujer")){
//            System.out.println("Usted se puede jubilar!");
//        }else if(edad>=65 && genero.equals("hombre")){
//            System.out.println("Usted se puede jubilar!");
//        }else{
//            System.out.println("Usted no se puede jubilar.");
//        }
        
        if(edad >= 60 && genero.equals("mujer") || edad>=65 && genero.equals("hombre") ){
            System.out.println("Usted se puede jubilar!");
        }else{
            System.out.println("Usted no se puede jubilar.");
        }
        
        System.out.println("\n**Estructura if-else anidado**");
        
        String usuario = "pepito";
        String clave = "1234";
        
        if(usuario.equals("pepito")){
            if(clave.equals("1234")){
                System.out.println("Bienvenido!");
            }else{
                System.out.println("Su clave es incorrecta.");
            }
        }else{
            System.out.println("Usuario incorrecto.");
        }
        
        edad = 18;
        boolean tienePasaporte = true;
        
        if(tienePasaporte){
            if(edad>=18){
                System.out.println("Usted puede viajar");
            }else{
                System.out.println("Debe viajar acompa�ado de un mayor");
            }
        }else{
            System.out.println("Usted no puede viajar");
        }
        
        
    }
}

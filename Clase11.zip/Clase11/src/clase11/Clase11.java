/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase11;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Crear una aplicaci�n que valide el ingreso a una
        plataforma Online Banking a trav�s de una clave Token.
        
        Se debe tener en cuenta lo siguiente:
        * La Clave Token debe ser un n�mero aleatorio
        de 6 d�gitos.
        * El cliente debe ingresar los campos Usuario,
        Contrase�a y Clave Token (todos obligatorios).
        * El campo Usuario no distingue min�sculas
        o may�sculas.
        * El campo Contrase�a es sensible a las
        min�sculas y may�sculas.
        La clave Token aleatoria se le informa al usuario al 
        pedirle que ingrese las credenciales.        
        * El cliente solo posee 3 intentos de logueo. 
	* Si alcanza los 3 intentos fallidos de forma
        consecutiva, la aplicaci�n deber� informar al
        usuario que debe dirigirse a la sucursal del
        banco m�s cercana para poder desbloquear
        sus credenciales.
        * Por cada intento fallido, la aplicaci�n debe
        preguntar al cliente si desea continuar
        colocando las credenciales de manera correcta.
        * Si el cliente coloca las credenciales de forma
        correcta, deber� informar que ha ingresado
        correctamente al Online Banking.
        */
        
        Scanner teclado = new Scanner(System.in);
        
        String usuarioCorrecto = "prueba123";
        String claveCorrecta ="1234prueba";
        int tokenCorrecto = 123456;
        int bienHecho = 0;
        int intentos = 0;
        System.out.println("El usuario es: " + usuarioCorrecto + 
                "\n la contrase�a es: " + claveCorrecta + "\n el token correcto es " 
                + tokenCorrecto);
        System.out.print("Ingrese un usuario --> ");
        String usuario = teclado.next().toLowerCase();
        System.out.print("Ingrese la contrase�a --> ");
        String clave = teclado.next();
        System.out.print("Ingrese el token --> ");
        int token = teclado.nextInt();
        
        while (bienHecho==0) {
            if(usuario.equals(usuarioCorrecto) && 
                    clave.equals(claveCorrecta) && 
                    token==tokenCorrecto){
                bienHecho++;
            }else{
                intentos++;
                if(intentos==3){
                    System.out.println("Debe dirigirse a la sucursal m�s cercana "
                            + "para poder desbloquear sus credenciales.");
                    System.exit(0);
                }else{
                    System.out.println("Los datos que ingresaste est�n incorrectos.\n"
                            + "l�mites de intentos " + intentos + "/3\nDesea seguir "
                                    + "intentando?\n1=si\n2=no\n-->");
                    int decisi�n  = teclado.nextInt();
                    if(decisi�n==1){
                        System.out.print("Ingrese un usuario --> ");
                        usuario = teclado.next().toLowerCase();
                        System.out.print("Ingrese la contrase�a --> ");
                        clave = teclado.next();
                        System.out.print("Ingrese el token --> ");
                        token = teclado.nextInt();
                    }else{
                        System.exit(0);
                    }
                }
            }
        }
        
        System.out.println("Ingresaste a On Line Banking");
        
    }
    
}



package clase11;

import java.util.Scanner;


public class EjercicioResuelto {
    public static void main(String[] args) {
    
        //a desarrollar en la pr�xima clase
        
    }
}

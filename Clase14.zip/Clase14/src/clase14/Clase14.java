
package clase14;

import java.util.Scanner;


public class Clase14 {

    public static void main(String[] args) {
        /*
        Crear un programa que ingrese una oraci�n y
        muestre cu�l es el caracter que m�s se repite.
        Consideraciones:
        * No debe incluir el espacio en blanco.
        * La oraci�n a ingresar no debe estar vac�a.
        * S�lo se mostrar� el primer caracter que m�s veces aparezca.
        */
        
        String oracion;
        Scanner teclado = new Scanner(System.in);
        
        //utilizamos el do while para validar que la oraci�n no sea vac�a
        do {
            System.out.println("Por favor, ingrese una oraci�n que no est� vac�a:");
            oracion = teclado.nextLine();
            if(oracion.isBlank()){
                System.out.println("Recuerde que la oraci�n no debe estar vac�a. Intente nuevamente.");
            }
        } while (oracion.isBlank());
        
        oracion = oracion.toLowerCase();
        
        //declaramos las variables que necesitamos para resolver el problema
        char caracterMasRepetido = oracion.charAt(0);
        int cantidadTotalDeRepeticiones = 0;
        
        for(int i=0; i<oracion.length(); i++){
            
            //almacenamos temporalmente el caracter actual del recorrido
            char caracterActual = oracion.charAt(i);
            
            //ignoramos el caracter espacio
            if(caracterActual == ' ') continue;
            
            //creamos un contador parcial
            int recuento = 1;
            
            //contamos cu�ntas veces se repite el caracter en la oraci�n
            for(int j=i+1; j<oracion.length(); j++){
                if(oracion.charAt(j) == caracterActual) recuento++;
            }
            
            //comprobamos si es el caracter que m�s se repite
            //si lo es, reemplazamos los valores generales
            if(recuento>cantidadTotalDeRepeticiones){
                cantidadTotalDeRepeticiones = recuento;
                caracterMasRepetido = caracterActual;
            }
            
        }
        
        System.out.println("El primer caracter que m�s se repite en la oraci�n "
                + "es \'" + caracterMasRepetido + "\'");
        System.out.println("Que se repite " + cantidadTotalDeRepeticiones + " veces.");
        
        
        
    }
    
}



package clase10;

import java.util.Scanner;


public class EstructurasRepetitivas {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("**Estructura while**");
        
        //la estructura while eval�a una condici�n y mientras sea verdadera
        //ejecuta las sentencias del cuerpo del while
        
        //imprimimos los n�meros del 1 al 10 uno debajo del otro
        
        int contador = 1;
        
        while(contador <= 10){
            System.out.println(contador);
            contador++;
        }
        
        System.out.println("Fin de la estructura while");
        
        //bucle infinito
//        contador = 1;
//        while(contador<=10){
//            System.out.println(contador);
//        }
        
//        contador = 1;
//        while(contador>=1){
//            System.out.println(contador);
//            contador++;
//        }
        
        System.out.println("**Estructura do-while**");
        
        //la estructura do-while siempre ejecuta el bloque de sentencias
        //al menos una vez y luego eval�a la condici�n
        String opcion;
        do {
            System.out.println("Bienvenido al juego de trivia");
            System.out.println("�Cu�l es la capital de Argentina?");
            System.out.println("Elija la letra de la opci�n");
            System.out.println("A- La Paz");
            System.out.println("B- Quito");
            System.out.println("C- Ciudad Aut�noma de Buenos Aires");
            System.out.println("D- Caracas");
            opcion = teclado.next().toUpperCase();
            if(opcion.equals("C")) System.out.println("Felicitaciones! Opci�n correcta");
            else System.out.println("Opci�n incorrecta. Vuelva a intentar...");
        } while (!opcion.equals("C"));
        
        
        //sumar los n�meros positivos ingresados por teclado
        
        int numero;
        int suma = 0;
        
//        do {
//            System.out.println("Ingrese un n�mero entero para sumar "
//                    + "o el 0(cero) para salir");
//            numero = teclado.nextInt();
//            if(numero>0) suma += numero; 
//        } while (numero!=0);
        
//        System.out.println("Usted ingres� el 0(cero) para salir.");
//        System.out.println("El resultado de la suma de los n�meros positivos es: " + suma);
        
        System.out.println("Sentencia break");
        //la sentencia break genera un corte en la secuencia de comandos
        //y saca la ejecuci�n del bloque de c�digo
        
        //siguiendo con el ejemplo anterior, vamos a cortar la ejecuci�n
        //si la suma supera los 100
//        do {
//            System.out.println("Ingrese un n�mero entero para sumar "
//                    + "o el 0(cero) para salir");
//            numero = teclado.nextInt();
//            if(numero>0) suma += numero; 
//            if(suma>100) break;
//        } while (numero!=0);
        
//        System.out.println("La suma de todos los n�meros positivos ingresados "
//                + "fue de: " + suma);
        
        System.out.println("Sentencia continue");
        
        //La sentencia continue genera un corte en la secuencia de comandos
        //y vuelve al principio de la estructura
        
        //ahora en nuestro ejemplo, s�lo sumaremos n�meros pares
        do {
            System.out.println("Ingrese un n�mero entero para sumar "
                    + "o el 0(cero) para salir");
            numero = teclado.nextInt();
            if(numero%2!=0) continue;
            if(numero>0) suma += numero; 
            if(suma>100) break;
        } while (numero!=0);
        
        System.out.println("La suma de los n�meros pares positivos ingresados "
                + "es de: " + suma);       
        
        
    }
}

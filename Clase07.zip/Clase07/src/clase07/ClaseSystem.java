
package clase07;

import java.util.Scanner;


public class ClaseSystem {
    public static void main(String[] args) {
        
        System.out.println("** Clase System **");
        
        /*
        La clase System es un intermediario entra la m�quina virtual de Java
        y el entorno de ejecuci�n en el que estamos ejecutando nuestro programa.
        Como la m�quina virtual de Java se puede ejecutar sobre m�ltiples
        plataformas, la clase System nos abstrae de la plataforma sobre la cual
        se est� ejecutando. Es decir, que no importa el SO sobre el que estemos
        trabajando.
        */
        
        //los atributos m�s cl�sicos con out, err, in
        //representan streams de entrada y salida
        //son atributos finales y est�ticos
        //out es un stream de salida sincronizado
        //err es un stream de salida desincronizado
        
        /*
        stream (flujo o corriente) es una secuencia de datos que se procesa
        o transmite de forma secuencial, en lugar de cargarse o procesarse
        en su totalidad antes de utilizarse.
        */
        
        System.out.println("Hola 1");
        System.out.println("Hola 2");
        System.out.println("Hola 3");
        System.out.println("Hola 4");
        System.out.println("Hola 5");
        System.out.println("Hola 6");
        System.out.println("Hola 7");
        System.out.println("Hola 8");
        System.out.println("Hola 9");
        System.out.println("Hola 10");
        System.out.println("Hola 11");
        System.out.println("Hola 12");
        System.out.println("Hola 13");
        System.out.println("Hola 14");
        System.out.println("Hola 15");
        System.out.println("Hola 16");
        System.out.println("Hola 17");
        System.out.println("Hola 18");
        System.out.println("Hola 19");
        System.out.println("Hola 20");
        System.err.println("Ocurri� un error!");
        
        //.exit()
        //cierra el runtime, es decir, que finaliza el programa
        //System.exit(0);
        //System.out.println("Esta l�nea no se ejecuta");
        //el par�metro 0 indica que no hubo error al finalizar el programa
        //el par�metro 1 significa que hubo un error
        //el par�metro -1 indica que hubo una advertencia
        
        //diccionario .getenv()
        //este m�todo devuelve un diccionarios de propiedades del entorno de
        //ejecuci�n, es decir, que son propiedades del sistema y var�an seg�n
        //el SO y la versi�n de Java
        System.out.println("");
        System.out.println("getenv()");
        System.out.println(System.getenv());
        
        //el .getProperties() representa un mapa o vector asociativo que es igual
        //en todaslas configuraciones
        System.out.println(System.getProperties()); //propiedad del sistema
        System.out.println(System.getProperty("os.name")); //nombre del sistema operativo
        System.out.println(System.getProperty("os.version")); //versi�n del SO
        System.out.println(System.getProperty("os.arch")); //arquitectura del SO
        System.out.println(System.getProperty("java.version")); //versi�n de JDK
        System.out.println(System.getProperty("user.name")); //nombre del usuario del SO
        System.out.println(System.getProperty("user.home")); //ruta directorio del usuario
        
        //El atributo in representa un stream de entrada y es sincronizado.
        //Permite ingresar datos desde la terminal del sistema
        //Por ejemplo, con la clase Scanner
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Ingrese su nombre:");
        String nombre = teclado.next();
        //el m�todo next() captura el texto hasta el primer espacio
        //detiene el hilo de ejecuci�n, el programa se queda esperando a
        //que el usuario ingrese el dato y presione enter
        System.out.println("Su nombre es: " + nombre);
        
        
        System.out.println("Ingrese su nombre y apellido:");
        teclado.nextLine();
        String nombreCompleto = teclado.nextLine(); //captura toda la l�nea
        System.out.println("Su nombre completo es: " + nombreCompleto);
        
        System.out.println("Ingrese su edad:");
        int edad = teclado.nextInt();
        System.out.println("Su edad es de: " + edad + " a�os.");
                
    }
}

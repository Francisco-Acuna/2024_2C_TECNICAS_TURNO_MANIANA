

package clase07;


public class ClaseString {
    public static void main(String[] args) {
        
        /*
        Formas de escritura:
        camel case -> estoEsUnaFraseEnCamelCase (tambi�n llamada lower camel case)
        pascal case -> EstoEsUnaFraseEnPascalCase (tambi�n llamada upper camel case)
        snake case -> esto_es_una_frase_en_snake_case
        */
        
        System.out.println("Clase String");
        
        //Es una clase. No es un tipo de dato primitivo.
        //Contiene un vector de caracteres
        
        //Podemos crear un objeto de la clase String de varias maneras:
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //m�todos para comparar
        //al comparar con el operador == se va a comparar que sean el 
        //mismo objeto en memoria
        System.out.println(texto3 == "hola"); //true, est�n en un mismo pool
        System.out.println(texto2 == "hola"); //false, no est�n en el mismo
        //lugar de memoria
        
        //para comparar cadenas de caracteres teniendo en cuenta su contenido
        //se utilizan .equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        System.out.println(texto3.equals("hola")); //true
        System.out.println(texto2.equals(texto3)); //true
        System.out.println(texto2.equals("Hola")); //false
        //para no tener en cuenta las may�sculas y min�sculas
        //utilizamos el .equalsIgnoreCase()
        System.out.println(texto2.equalsIgnoreCase("Hola")); //true
        
        //.contains()
        //devuelve un booleano indicando si la cadena contiene una subcadena dada
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto3.contains("hola")); //true
        System.out.println(texto2.contains("ol")); //true
        System.out.println(texto2.contains("lo")); //false
        
        //.length()
        //devuelve la longitud del vector, es decir, cu�ntos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        System.out.println(texto3.length()); //4
        
        //.isEmpty()
        //indica si la cadena est� vac�a, es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false
        
        
        //.isBlank() aparece a partir del JDK 11
        //indica si una cadena est� vac�a, en blanco, contiene solo espacios o
        //solo tabulaciones, o solo saltos de l�nea
        String texto4 = "   ";
        System.out.println(texto4.isEmpty()); //false
        System.out.println(texto4.isBlank()); //true
        
        //.charAt()
        //devuelve el caracter del �ndice pasado como par�metro
        System.out.println(texto1.charAt(5)); //a
        System.out.println(texto2.charAt(2)); //l
        //System.out.println(texto3.charAt(4)); 
        //error, no existe la posici�n 4 para un vector de longitud 4
        
        //.indexOf()
        //devuelve el �ndice de la primera ocurrencia de la subcadena
        //si no la encuentra, devuelve -1
        System.out.println(texto1.indexOf("ena")); //3
        System.out.println(texto1.indexOf("text")); //-1 la T es may�scula
        System.out.println(texto1.indexOf("Text")); //10
        System.out.println(texto1.indexOf("e")); //
        
        //.trim()
        //quita los espacios de adelante y de atr�s
        System.out.println("   buenas noches   ");
        System.out.println("   buenas noches   ".trim());
        
        //.startsWith() .endsWith()
        //devuelve un booleano si la cadena empieza o finaliza con un texto determinado
        System.out.println(texto1.startsWith("hola")); //false       
        System.out.println(texto1.startsWith("cadena")); //false
        System.out.println(texto2.startsWith("ho")); //true
        System.out.println(texto1.endsWith("exto")); //falso
        System.out.println(texto1.endsWith("o!")); //true
        
        
        //.replace()
        //reemplaza un caracter por otro
        System.out.println(texto1.replace('e', 'i'));
        System.out.println(texto1);
        //reemplaza una cadena de caracteres por otra
        System.out.println(texto1.replace("Texto", "caracteres"));
        //reemplazar solo la primera vez que aparezca la cadena
        texto3 = "manzana, manzana, naranja";
        System.out.println(texto3.replaceFirst("manzana", "banana"));
        //reemplazar todas las veces que aparezca la subcadena
        System.out.println(texto3.replaceAll("manzana", "banana"));
        //replace() tambi�n reemplaza todas las veces que aparezca, pero 
        //replaceAll() es m�s potente, permite reemplazar patrones de expresiones
        
        //.repeat()
        //repite la cadena la cantidad de veces que le indiquemos por par�metro
        System.out.println(texto2.repeat(3));
        
        //.substring()
        //devuelve una subcadena
        System.out.println(texto1.substring(7)); //devuelve a partir del �ndice dado
        System.out.println(texto1.substring(7,10)); //indico desde d�nde hasta d�nde
        //sin incluir el extremo
        
        //caracteres de escape
        /*
        Son secuencias especiales de caracteres que se utilizan en cadenas de textos
        y literales de caracteres, para representar caracteres especiales que no se
        pueden representar directamente.
        Los caracteres de escape comienzan con una barra invertida \ seguida del 
        caracter que indica qu� tipo de escape se est� utilizando.
        */
        
        // \n salto de l�nea
        System.out.println("Hola\nMundo!");
        
        // \t tabulaci�n
        System.out.println("Hola\tMundo!");
        
        // \" comillas dobles
        System.out.println("\"Hola Mundo\"");
        
        // \' comillas simples
        System.out.println("\'Hola Mundo!\'");
        
        // \\ contrabarra o barra invertida
        System.out.println("\\Hola Mundo!\\");
        
    }
}

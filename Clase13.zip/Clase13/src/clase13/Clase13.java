/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase13;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*
        Imprimir los n�meros del 1 al 10, sin imprimir
        n�meros 2, 5 y 9, uno abajo del otro.
        */
        
//        for(int i=1; i<=10; i++){
//            if(i!=2 && i!=5 && i!=9){
//                System.out.println(i);
//            }
//        }
        
        /*
        Imprimir los n�meros del 1 al 30 sin imprimir
        n�meros entre el 10 y el 20 uno abajo del otro
        */
        
//        for(int i=1; i<=30; i++){
//            if(i<=10 || i>=20){
//                System.out.println(i);
//            }
//        }
        
        /*
        Imprimir los n�meros del 1 al 10 salteando de
        a dos, uno abajo del otro.

        Imprimir los n�meros del 10 al 1, uno al lado
        del otro.
        
        Imprimir la suma de los n�meros impares del
        1 al 10.
        */
         
//        for(int i=1; i<=10; i+=2){
//            System.out.println(i);
//        } 

//        for(int i=10; i>=1; i--){
//            System.out.print(i);
//        }
        
//        int suma = 0;
//        
//        for(int i=1; i<=10; i+=2){
//            suma+=i;            
//        }    
//        System.out.println("La suma de los n�meros impares es: " + suma);
        
        /*
        Una persona desea invertir $1000 en un banco, el
        cual le otorga un 2% de inter�s mensual �Cu�l
        ser� la cantidad de dinero que esta persona
        tendr� al cabo de un a�o?
        En el primer mes tendr� acumulado 1000 $ m�s
        20 $ de inter�s ( 2% de 1000 ). En el segundo
        mes se le sumar� un 2% a la base de 1020 $ del
        mes anterior y as� sucesivamente.
        */
        
                
        double interes = 2;
        double capitalInicial = 1000;
        double montoAcumulado = capitalInicial;
        int mes = 12;
        
        for(int i=1; i<=mes; i++){
            System.out.println("Su capital inicial en este mes es de: $" + Math.round(montoAcumulado));
            System.out.println("El inter�s en el mes " + i + " es del %" + interes);
            double interesMensual = montoAcumulado/100*interes;
            System.out.println("Que representa una ganancia de $" + Math.round(interesMensual));
            montoAcumulado += interesMensual;
            System.out.println("\n######################################\n");
        }
        
        System.out.println("Su saldo total al finalizar el a�o es de: $" + Math.round(montoAcumulado));
        
        System.out.println("\n\n****************************************\n\n");
        //Nota: explicamos el uso del Decimal Format
        //La clase Decimal Format nos va a permitir modificar un n�mero con decimales
        //al transformarlo en una cadena con la cantidad de decimales que necesitemos
        
//        double nro1 = 10;
//        double nro2 = 3;
//        double division = nro1/nro2;
//        
//        DecimalFormat df = new DecimalFormat("#.##");
//        String divisionRedondeada = df.format(division);
//        
//        System.out.println(division);
//        System.out.println(Math.round(division));
//        System.out.println("$"+divisionRedondeada);
//        
//        System.out.println("\n\n****************************************\n\n");
        
        /*
        Crear un programa que ingrese una oraci�n y
        muestre cu�l es el car�cter que m�s se repite.
        Consideraciones
        * No debe incluir el espacio en blanco.
        * La oraci�n a ingresar no debe estar vac�a.
        */    
        /*
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese una oraci�n:");
        String oracion = teclado.nextLine();
        
        int contador = 0;
        char letraRepetida = 0;
        for(int i=0; i<oracion.length(); i++){
            int contadorActual = 0;
            for(int j=0; j<oracion.length(); j++){
                if(oracion.charAt(i) == oracion.charAt(j)){
                    if(oracion.charAt(j) != ' '){
                        contadorActual ++;
                    }
                }
                
                if(contador<contadorActual){
                    contador = contadorActual;
                    char letra = oracion.charAt(j);
                    letraRepetida = letra;
                }
            }
        }
        
        System.out.println("La primera letra m�s repetida es la: " + letraRepetida);
        System.out.println("Se repite " + contador + " veces.");
        
        */
        
    }
    
}

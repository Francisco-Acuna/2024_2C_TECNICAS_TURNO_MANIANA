package clase17;


public class Clase17 {


    public static void main(String[] args) {
        //si tuviera que guardar varios números en variables
        int numero1 = 10;
        int numero2 = 20;
        int numero3 = 50;
        int numero4 = 125;
        
        
        /*
        Podemos generar un conjunto de variables que tengan un mismo nombre
        que las agrupe a todas.
        Podemos acceder a cada variable por medio del índice.
        Recordemos que los índices comienzan en 0.
        De esta manera optimizamos la lectura de la información para 
        acceder por un mismo nombre a distintas variables y no por el nombre
        de cada una de ellas.
        */
        
        
        
        System.out.println("Arreglos o Arrays");
        
        /*
        declaración:
        tipoDeDato[] identificador; --> declaración
        tipoDeDato identificador[]; --> declaración
        identificador = new tipoDeDato[n]; --> definición de longitud
        la longitud es la cantidad de variables que va a tener el arreglo
        */
        
        
        
        
    }
    
}

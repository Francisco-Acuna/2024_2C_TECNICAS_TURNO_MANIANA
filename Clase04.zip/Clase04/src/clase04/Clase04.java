/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        ################################
         M�S TIPOS DE DATOS PRIMITIVOS
        ################################
        */
        
        // boolean
        // ocupa 1 byte y almacena solo 2 valores (0 y 1)
        // representados por los true y false
        boolean l = true;
        boolean m = false;
        System.out.println(l);
        System.out.println(m);
        
        // char
        // ocupa 2 bytes 
        // almacena un entero que representa un caracter de la tabla unicode
        char n = 65;
        System.out.println(n);
        //si a una may�scula le sumo 32, la paso a min�scula
        n += 32; //le sumo 32 a la variable
        System.out.println(n);
        n = 'f'; //el caracter va representado entre comillas simples
        System.out.println(n);
        
        
        // String
        // NO ES UN TIPO DE DATO PRIMITVO - ES UNA CLASE
        String o = "Hola"; //la literal va entre comillas dobles
        //al ser una clase String va con la S may�scula
        String p = "Hola, soy una cadena de caracteres";
        System.out.println(o);
        System.out.println(p);
        
        
        // ## CONSTANTES ##
        
        // son similares a las variables, pero la diferencia es que
        //su valor no puede cambiar
        // deben llevar la palabra final en su declaraci�n
        // por convenci�n el nombre de la constante debe ir en may�scula
        final double PI = 3.14;
//        PI = 3.15; error, su valor no puede cambiar


        // concatenaci�n
        // operador +
        String nombre = "Marcelo";
        String apellido = "Cuendias";
        System.out.println(nombre);
        System.out.println(apellido);
        System.out.println(nombre + apellido);
        System.out.println(nombre + " " + apellido);
        
        String palabra = "perro";
        System.out.println(palabra);
        System.out.println(palabra.toUpperCase()); // pasa a may�scula
//        String palabra2 = "GATO";
//        System.out.println(palabra2);
//        System.out.println(palabra2.toLowerCase()); // pasa a min�scula
        
        System.out.println("");
        System.out.println("********************************");
        System.out.println("");

        /*
        ######################
            OPERADORES
        ######################
        */
        
        //Operadores aritm�ticos
        /*
        + suma
        - resta
        * multiplicaci�n
        / divisi�n
        % m�dulo o resto de la divisi�n
        Son operadores binarios porque necesitan 2 operandos
        Los operandos son num�ricos, el resultado es num�rico
        */

        int nro1 = 10;
        int nro2 = 2;
        
        System.out.print("Suma: ");
        System.out.println(nro1 + nro2);

        System.out.print("Resta: ");
        System.out.println(nro1 - nro2);
        
        System.out.print("Multiplicaci�n: ");
        System.out.println(nro1 * nro2);
        
        System.out.print("Divisi�n: ");
        System.out.println(nro1 / nro2);
        
        System.out.print("M�dulo o resto: ");
        System.out.println(nro1 % nro2);
        
        
        //Operadores de asignaci�n
        /*
        =   asignaci�n
        +=  suma y asignaci�n
        -=  resta y asignaci�n
        *=  multiplicaci�n y asignaci�n
        /=  divisi�n y asignaci�n
        %=  m�dulo y asignaci�n
        Son operadores binarios.
        Asignan el valor a una variable y se la modifican utilizando 
        una expresi�n.
        */
        
        
        System.out.println(nro1); //10
        System.out.println(nro1 += 2); //12
        System.out.println(nro1); //12
        System.out.println(nro1 -= 2); //10
        System.out.println(nro1 *= 2); //20
        System.out.println(nro1 /=2); //10
        System.out.println(nro1 %=3); //1
        
        
        //Operadores incrementables y decrementables
        /*
        ++ incremento en 1
        -- decremento en 1
        Son operadores unarios, trabajan con un solo operando.
        */
        
        System.out.println(nro1); //1
        nro1++;
        System.out.println(nro1); //2
        nro1--;
        System.out.println(nro1); //1
        
        
        //Operadores relacionales
        /*
        >   mayor
        <   menor
        >=  mayor o igual
        <=  menor o igual
        ==  igual
        !=  distinto
        Son operadores binarios.
        Los operandos son num�ricos y el resultado es booleano.
        */
        
        nro1 = 15;
        nro2 = 20;
        
        System.out.println(nro1 > nro2); //false
        System.out.println(nro1 < nro2); //true
        System.out.println(nro1 >= nro2); //false
        System.out.println(nro1 <= nro2); //true
        System.out.println(nro1 == nro2); //false
        System.out.println(nro1 != nro2); //true
        
        
        //Tabla de verdad
        //es una representaci�n l�gica de resultados
        /*
        A   B   AND OR
        V   V   V   V
        V   F   F   V
        F   V   F   V
        F   F   F   F
        
        Negaci�n (NOT)
        A   NOT
        V   F
        F   V
        */
                
        //Operadores l�gicos
        /*
        &   AND
        |   OR
        !   NOT
        Los operandos son booleanos.
        El resultado es booleano.
        */
        
        boolean log1 = true;
        boolean log2 = false;
        
        /*
        Un solo operador l�gico & o | eval�a ambas condiciones.
        Al utilizar dos && o || si con una condici�n determinar el
        valor de verdad, no eval�a la que sigue.
        */
        
        System.out.print("AND &&:");
        System.out.println(log1 && log2); //false
        
        System.out.print("OR ||:");
        System.out.println(log1 || log2); //true
        
        System.out.print("NOT:");
        System.out.println(!log1); //false
        System.out.print("NOT:");
        System.out.println(!log2); //true
        
        /*
        $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
        */
        
        //Resoluci�n de Ejercicio 3:
        int n1 = 5;
        int n2 = 10;
        
        System.out.println("n1 es igual a " + n1 + ", n2 es igual a " + n2
                            + " y n1 m�s n2 es igual a " + (n1+n2));
    
        
    }
    
}

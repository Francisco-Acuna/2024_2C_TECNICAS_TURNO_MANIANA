
package clase16;

import java.util.Scanner;


public class Clase16 {


    public static void main(String[] args) {
        //Ejercicios funciones
        //1. crear una funci�n que devuelva la cantidad de vocales de una palabra
        //hecho la clase pasada
         
        //2. crear una funci�n que indique si un n�mero es m�ltiplo de 3
        Scanner teclado = new Scanner(System.in);
//        System.out.println("Ingrese un n�mero entero para saber si es "
//                + "m�ltiplo de 3:");
//        int numero = teclado.nextInt();
//        
//        boolean resultado = esMultiploDeTres(numero);
//        
//        System.out.println("El resultado fue: " + resultado);
        
        // 3. crear una funci�n que aplique %50 de premio si el ingreso es 
        //de m�s de 35.000
//        System.out.println("Ingrese el monto:");
//        float monto = teclado.nextFloat();
//        if(monto<0) System.out.println("El monto no puede ser negativo");
//        else System.out.println("El valor final es: " + aplicarPremio(monto, 50));
        
        //Procedimientos 
        //1. Crear un procedimiento que calcule el �rea del tri�ngulo y 
        //lo informe por pantalla
//        System.out.println("Ingrese la base del tri�ngulo:");
//        float baseTriangulo = teclado.nextFloat();
//        System.out.println("Ingrese la altura del tri�ngulo:");
//        float alturaTriangulo = teclado.nextFloat();
//        calcularAreaTriangulo(baseTriangulo, alturaTriangulo);
        
        //2. Crear un procedimiento que muestre por pantalla el valor del IVA 
        //de un producto ingresado como par�metro
//        System.out.println("Ingrese un valor para calcular el monto del IVA:");
//        float monto = teclado.nextFloat();
//        devolverValorDelIva(monto, 21);

        //3. Crear un procedimiento que muestre por pantalla la cantidad de 
        //n�meros impares que ingresa el usuario y lo informe por pantalla
//        contarCantidadNumerosImpares();
        
        /*
        Crear un programa que reciba 3 par�metros y calcule la suma, resta, 
        multiplicaci�n, divisi�n y el resto de dos n�meros con decimales. 
        Las consignas para lograrlo son:
        * Debe crear un procedimiento, que reciba los 3 par�metros: 2 n�meros 
        con decimales y el car�cter de operaci�n.
        * Debe crear las funciones de las operaciones que retornen un n�mero 
        con decimales.
        * Debe mostrar por consola un mensaje que indique el resultado y la 
        operaci�n realizada
        */
        System.out.println("Bienvenido a nuestra aplicaci�n de c�lculos aritm�ticos:");
        System.out.println("Ingrese el primer n�mero");
        double primerNumero = teclado.nextDouble();
        System.out.println("Ingrese el segundo n�mero");
        double segundoNumero = teclado.nextDouble();
        System.out.println("Ingrese el operador");
        char operador = teclado.next().charAt(0);
        
        realizarOperacionAritmetica(primerNumero, segundoNumero, operador);
        
        
    }
    
    public static boolean esMultiploDeTres(int numero){
        return numero % 3 == 0;
    }
    
    public static float aplicarPremio(float ingreso, float premio){
        float devolucion = ingreso;
        if(ingreso>35000) devolucion += ingreso /100 * premio;
        return devolucion;
    }

    public static void calcularAreaTriangulo(double base, double altura){
        double area = (base * altura) / 2;
        System.out.println("El �rea del tri�ngulo es: " + area);
    }
    
    public static void devolverValorDelIva(double precio, double valorIva){
        double resultado = precio / 100 * valorIva;
        System.out.println("El monto del IVA es de: " + resultado);
    }
    
    public static void contarCantidadNumerosImpares(){
        Scanner lector = new Scanner(System.in);
        int numero;
        int cantidadNrosImpares = 0;
        do {
            System.out.println("Ingrese un n�mero entero o el 0 para salir");
            numero = lector.nextInt();
            if(numero%2!=0) cantidadNrosImpares++;
        } while (numero != 0);
        System.out.println("La cantidad de n�meros impares ingresados "
                + "fue de: " + cantidadNrosImpares);
    }
    
    public static void realizarOperacionAritmetica(double num1, double num2, 
            char operador){
        double resultado = 0;
        String operacion = "";
        String mensaje = "El resultado de la operaci�n es: " + resultado
                + "\n y la operaci�n realizada fue: " + operacion;
        switch(operador){
            case '+': 
                resultado = sumar(num1, num2); 
                operacion = "suma"; break;
            case '-': 
                resultado = restar(num1, num2); 
                operacion = "resta"; break;
            case '*': 
                resultado = multiplicar(num1, num2); 
                operacion = "multiplicaci�n"; break;
            case '/': 
                if(num2!=0){
                    resultado = dividir(num1, num2);
                    operacion = "divisi�n";
                } else{
                    mensaje = "No se puede dividir por 0 animal.";
                }
                break;
            case '%': 
                if(num2!=0){
                    resultado = obtenerResto(num1, num2); 
                    operacion = "obtener resto";
                } else{
                    mensaje = "No se puede dividir por 0 animal.";
                }
                break;
            default: mensaje = "La operaci�n no se pudo realizar, porque el operador"
                    + " ingresado no es v�lido.";    
        }
        System.out.println(mensaje);
    }
    
    
    public static double sumar(double nro1, double nro2){
        return nro1 + nro2;
    }
    
    public static double restar(double nro1, double nro2){
        return nro1 - nro2;
    }
    
    public static double multiplicar(double nro1, double nro2){
        return nro1 * nro2;
    }
    
    public static double dividir(double nro1, double nro2){
        return nro1 / nro2;
    }
    
    public static double obtenerResto(double nro1, double nro2){
        return nro1 % nro2;
    }
    
}
